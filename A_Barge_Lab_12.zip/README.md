CU-CSCI3308-CIPractice
======================

Assignment to practice the use of continuous integration tools.

### Author
Andy Sayler  
Univerity of Colorado  
CSCI 3308  
Summer 2014

### Requirements
sudo apt-get install check
