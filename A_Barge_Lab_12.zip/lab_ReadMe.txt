Aaron Barge and David Blair


Aaron's
git hub link:  	https://github.com/Bargey13/CU-CSCI3308-CIPractice

David's 
Git hub link: 	https://github.com/david-blair/CU-CSCI3308-CIPractice

Travis link: https://travis-ci.org/Bargey13/CU-CSCI3308-CIPractice